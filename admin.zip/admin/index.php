<?php 

header('location:BuyNow.php');

?>